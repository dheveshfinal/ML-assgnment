import streamlit as st
import pickle
import numpy as np
import pandas as pd

# Load the trained model
try:
    model = pickle.load(open('logistic_regression_model.pkl', 'rb'))
except FileNotFoundError:
    st.error("Model file 'logistic_regression_model.pkl' not found.")
    st.stop()

# Streamlit app
st.title('Titanic Survival Prediction')

# Input fields for the user to enter data
pclass = st.selectbox('Pclass', [1, 2, 3])
age = st.number_input('Age', min_value=0, max_value=100)
sibsp = st.number_input('SibSp')
parch = st.number_input('Parch')
fare = st.number_input('Fare')
sex = st.selectbox('Sex', ['male', 'female'])
embarked = st.selectbox('Embarked', ['C', 'Q', 'S'])

# Preprocess the inputs
sex_male = 1 if sex == 'male' else 0
embarked_C = 1 if embarked == 'C' else 0
embarked_Q = 1 if embarked == 'Q' else 0
embarked_S = 1 if embarked == 'S' else 0

# Create input data for the model
input_data = np.array([pclass, age, sibsp, parch, fare, sex_male, embarked_C, embarked_Q]).reshape(1, -1)

# Make prediction
try:
    prediction = model.predict(input_data)
except Exception as e:
    st.error(f"Error during prediction: {e}")
    st.stop()

# Show prediction result
if prediction == 1:
    st.success("Survived!")
else:
    st.warning("Did not survive.")